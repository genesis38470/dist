#!/bin/bash
while [ 1 ]
do
  ./coinsaurus_miner
done
